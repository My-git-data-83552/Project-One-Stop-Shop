import NaviBar from '../components/Navigation_bar';

export const Product=()=>{


    return (
        <div className="container-fluid">
            <NaviBar/>
        </div>
    )
}





